package com.example.demo;

public class SubmissionForm {
    public String Name;

    public String getId() {
        return Id;
    }

    public void setId(String id) {
        Id = id;
    }

    public String Id;
    public String VendorName;
    public int rate;
    public String leadName;
    public String Technology;





}
